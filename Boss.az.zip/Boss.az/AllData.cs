﻿using Newtonsoft.Json;

namespace Boss.az;

public class AllData
{
   
    public static Main main { get; set; }
    public static void SerializeConfig()
    {
        string json = JsonConvert.SerializeObject(main);
        File.WriteAllText("System.json", json);
    }

    public static void DeserializeConfig()
    {
        if (File.Exists("System.json"))
        {
            string json = File.ReadAllText("System.json");
            main = JsonConvert.DeserializeObject<Main>(json);
        }
        else
        {
            main = new();
        }
    }
}

