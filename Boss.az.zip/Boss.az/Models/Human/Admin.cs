﻿using Boss.az.Models.UserInfo;
using Boss.az.Models.Work;
using System.ComponentModel.Design;

namespace Boss.az.Models.Human;
public class Admin : Person
{
    public static List<Notification> AdminNotifications = new();
    public static List<Vacancy> AdminVacancies = new();
    public static List<Employer> RemovedEmployers = new();
    public static List<Worker> RemovedWorkers = new();
    public Admin() : base("Admin", "Admin", "Shamkir", "55 555 55 55", 20, "Admin", "Admin123", "Admin@gmail.com")
    {

    }
    public void AdminMenu()
    {
        string[] arr = new string[6] { "All Workers", "All Employers", "All Vacancies", "All Notifacations", "All logs", "Exit" };
        int select = 0;
        while (true)
        {
            Console.Clear();
            Main.Show(arr, select, false);
            int a = Main.Control(arr.Length, ref select);
            if (a == -1)
                return;

            else if (a == 1)
                if (select == 0)
                {
                    int option = Main.PrintList<Worker>(Main.workers, "Workers", false);
                    if (option != -1)
                    {
                        int m = Selectoption();
                        if (m == 1)
                        {
                            RemovedWorkers.Add(Main.workers[option]);
                            Main.workers.RemoveAt(option);
                            Main.AddLog($"Admin deleted Worker: {Main.employers[option]} -> ");
                        }
                    }
                }

                else if (select == 1)
                {
                    int option = Main.PrintList<Employer>(Main.employers, "Employes", false);
                    if (option != -1)
                    {
                        int m = Selectoption();
                        if (m == 1)
                        {
                            RemovedEmployers.Add(Main.employers[option]);
                            Main.employers.RemoveAt(option);
                            Main.AddLog($"Admin deleted Employer: {Main.employers[option]} -> ");
                        }
                    }
                }

                else if (select == 2)
                    AllVacancies();

                else if (select == 3)
                    AllNotifications();

                else if (select == 4)
                {
                    Console.Clear();
                    string jsonContent = File.ReadAllText(Main.path);
                    Console.WriteLine(jsonContent);
                    _ = Console.ReadKey(true);
                }
                else
                    return;
        }
    }
    public static int Selectoption(string content = "Do you want to delete?")
    {
        string[] arr1 = new string[3] { "Yes", "No", "Exit" };
        int sl = 0;
        while (true)
        {
            Console.Clear();
            Console.WriteLine(Main.font);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"\t\t\t{content}");
            Console.ForegroundColor = ConsoleColor.White;
            Main.Show(arr1, sl);
            int a = Main.Control(arr1.Length, ref sl);
            if (a == -1)
                return -1;

            else if (a == 1)
                if (sl == 0)
                    return 1;
                else if (sl == 1)
                    return 2;
                else
                    return -1;
        }
    }
    public static void AllNotifications()
    {
        string[] arr = new string[3] { "Checked", "Unchecked", "Deleted" };
        int sl = 0;
        while (true)
        {
            Console.Clear();
            Main.Show(arr, sl);
            int k = Main.Control(arr.Length, ref sl);
            if (k == -1)
                return;

            else if (k == 1)
            {
                List<Notification> temp = new();
                if (sl == 0)
                {
                    foreach (var v in AdminNotifications)
                        if (v.Visiblity == 1)
                            temp.Add(v);
                    int option = Main.PrintList<Notification>(temp, "Checked Notifications");
                    if (option != -1)
                        if (Selectoption() == 1)
                        {
                            temp[option].Visiblity = -1;
                            Main.AddLog($"Admin deleted notification Id: {temp[option].Id} -> ");

                        }
                }

                else if (sl == 1)
                {
                    foreach (var a in AdminNotifications)
                        if (a.Visiblity == 0 || a.Visiblity == 2)
                            temp.Add(a);
                    int option = Main.PrintList<Notification>(temp, "Unchecked Notifications", false);
                    if (option != -1)
                    {
                        int a = 0;
                        string[] str = new string[2] { "Allow", "Deny" };
                        while (true)
                        {
                            Console.Clear();
                            Main.Show(str, a);
                            int control = Main.Control(str.Length, ref a);
                            if (control == -1)
                                break;

                            else if (control == 1)
                            {
                                if (a == 0)
                                {
                                    Main.AddLog($"Admin allowed notification Id: {temp[option].Id} -> ");

                                    if (temp[option].Visiblity == 0)
                                        temp[option].Visiblity = 1;
                                    foreach (var user in Main.workers)
                                        if (user.Username == temp[option].Receiver)
                                            user.AddNotification(temp[option]);
                                }
                                else if (a == 1)
                                {
                                    Main.AddLog($"Admin denied notification Id: {temp[option].Id} -> ");

                                    temp[option].Visiblity = -1;
                                }
                                break;
                            }
                        }
                    }
                }

                else
                {
                    foreach (var a in AdminNotifications)
                        if (a.Visiblity == -1)
                            temp.Add(a);
                    int option = Main.PrintList<Notification>(temp, "Deleted Notifications", false);
                    if (option != -1)
                        if (Selectoption("Do you want to restore") == 1)
                        {
                            temp[option].Visiblity = 1;
                            Main.AddLog($"Admin restored notification Id: {temp[option].Id} -> ");
                        }
                }

            }
        }
    }
    public static void AllVacancies()
    {
        string[] arr = new string[3] { "Checked", "Unchecked", "Deleted" };
        int sl = 0;
        while (true)
        {
            Console.Clear();
            Main.Show(arr, sl);
            int k = Main.Control(arr.Length, ref sl);
            if (k == -1)
                return;

            else if (k == 1)
            {
                List<Vacancy> temp = new();
                if (sl == 0)
                {
                    foreach (var v in AdminVacancies)
                        if (v.Visiblity == 1)
                            temp.Add(v);
                    int option = Main.PrintList<Vacancy>(temp, "Checked Vacancies");
                    if (option != -1)
                        if (Selectoption() == 1)
                        {
                            temp[option].Visiblity = -1;
                            Main.AddLog($"Admin deleted vacancy Id: {temp[option].Id} -> ");
                        }
                }

                else if (sl == 1)
                {
                    foreach (var a in AdminVacancies)
                        if (a.Visiblity == 0)
                            temp.Add(a);
                    int option = Main.PrintList<Vacancy>(temp, "Unchecked Vacancies", false);
                    if (option != -1)
                    {
                        int a = 0;
                        string[] str = new string[2] { "Allow", "Deny" };
                        while (true)
                        {
                            Console.Clear();
                            Main.Show(str, a);
                            int control = Main.Control(str.Length, ref a);
                            if (control == -1)
                                break;

                            else if (control == 1)
                            {
                                if (a == 0)
                                {
                                    temp[option].Visiblity = 1;
                                    Main.AddLog($"Admin allowed vacancy Id: {temp[option].Id} -> ");

                                }
                                else if (a == 1)
                                {
                                    temp[option].Visiblity = -1;
                                    Main.AddLog($"Admin denied vacancy Id: {temp[option].Id} -> ");
                                }
                                break;
                            }
                        }
                    }
                }

                else if (sl == 2)
                {
                    foreach (var v in AdminVacancies)
                        if (v.Visiblity == -1)
                            temp.Add(v);
                    int option = Main.PrintList<Vacancy>(temp, "Deleted Vacancies");
                    if (option != -1)
                        if (Selectoption("Do you want to restore") == 1)
                        {
                            temp[option].Visiblity = 1;
                            Main.AddLog($"Admin restored vacancy Id: {temp[option].Id} -> ");
                        }
                }
            }
        }
    }
}

