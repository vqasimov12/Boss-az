﻿using Boss.az.Models.Human;
using Boss.az.Models.Work;
using System.Net.Mail;
using System.Net;
using Newtonsoft.Json;

namespace Boss.az;
public class Main
{
    //public Main()
    //{
    //    workers = new();
    //    employers = new();
    //    Vacancies = new();
    //    admin = new();
    //}

    public static long OTPCode;
    public static List<Worker> workers = new();
    public static List<Employer> employers = new();
    public static List<Vacancy> Vacancies = new();
    public static Admin admin = new();
    public static string path = "MY LOGs.json";
    public static string font = @"
                              ____   ____   _____ _____            ______
                             |  _ \ / __ \ / ____/ ____|     /\   |___  /
                             | |_) | |  | | (___| (___      /  \     / / 
                             |  _ <| |  | |\___ \\___ \    / /\ \   / /  
                             | |_) | |__| |____) ____) |  / ____ \ / /__ 
                             |____/ \____/|_____|_____/  /_/    \_/_____|
                                                                         
                                             ";
    public static string Path
    {
        get { return path; }
        set
        {
            path = value;
        }
    }
    static bool Exists(string username)
    {
        foreach (var a in employers)
            if (a.Username == username)
                return true;
        foreach (var a in workers)
            if (a.Username == username)
                return true;
        return false;
    }
    public static void AddLog(string info)
    {
        using (StreamWriter writer = File.AppendText(path))
        {
            writer.WriteLine(info + DateTime.Now);
            writer.WriteLine();
        }
    }
    public static void LogThis(string logMessage)
    {

        if (!File.Exists(path))
            using (StreamWriter writer = new StreamWriter(path, true))
            {
                writer.WriteLine($"{logMessage}{DateTime.Now}");
                writer.WriteLine();
            }
        else
            AddLog(logMessage);
    }
    public void Start()
    {
        Worker w = new();
        w.Username = "User";
        w.Password = "Username1";
        workers.Add(w);
        Employer e = new();
        e.Username = "Username";
        e.Password = "Username1";
        employers.Add(e);
        Vacancies.Add(new());
        LogThis("\n\nProgram started  ->  ");
        int select = 0;
        string[] arr = new string[5] { "Workers", "Vacancies", "Sign In", "Sign Up", "Exit" };
        while (true)
        {
            Console.Clear();
            Show(arr, select);
            int a = Control(arr.Length, ref select);

            if (a == -1)
            {
                break;
            }


            else if (a == 1)
            {
                if (select == 0)
                    PrintList(workers, "Workers", false);

                else if (select == 1)
                {
                    List<Vacancy> temp = new();
                    foreach (var v in Vacancies)
                        if (v.Visiblity == 1)
                            temp.Add(v);
                    PrintList(temp, "Vacancies", false);
                }

                else if (select == 2)
                    SignIn();

                else if (select == 3)
                    SingUp();

                else if (select == 4)
                {
                    return;
                }
            }
        }
    }
    public static void Show(string[] arr, int select, bool color = true,string a="")
    {
        Console.WriteLine(font);
        Console.ForegroundColor = ConsoleColor.Cyan;
       Console.Write(a);
        Console.ForegroundColor = ConsoleColor.White;
        for (int i = 0; i < arr.Length; i++)
        {
            if (i == select)
            {
                Console.ForegroundColor = (color == true) ? ConsoleColor.Cyan : ConsoleColor.Green;
                Console.WriteLine("\t\t\t\t\t" + arr[i]);
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
                Console.WriteLine("\t\t\t\t\t" + arr[i]);
        }
    }
    public static void SingUp()
    {
        int select = 0;
        string[] arr = { "Employer", "Worker" };
        bool asWorker = false;
        while (true)
        {
            Console.Clear();
            Show(arr, select, false);
            int b = Control(arr.Length, ref select);
            if (b == -1)
                return;
            else if (b == 1)
            {
                if (select == 1)
                    asWorker = true;
                break;
            }
        }

        Person a;
        if (asWorker)
            a = new Worker();
        else
            a = new Employer();

        while (true)
            try
            {
                Console.Clear();
                Console.WriteLine(font);
                Console.Write("Name: ");
                a.Name = Console.ReadLine()!;
                break;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Try again");
                _ = Console.ReadKey(true);
            }

        while (true)
            try
            {
                Console.Clear();
                Console.WriteLine(font);
                Console.WriteLine($"Name: {a.Name}");
                Console.Write("Surname: ");
                a.Surname = Console.ReadLine()!;
                break;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Try again");
                _ = Console.ReadKey(true);
            }

        while (true)
            try
            {
                Console.Clear();
                Console.WriteLine(font);
                Console.WriteLine($"Name: {a.Name}\nSurname: {a.Surname}");
                Console.Write("City: ");
                a.City = Console.ReadLine()!;
                break;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine("Try again");
                _ = Console.ReadKey(true);

            }

        while (true)
            try
            {
                Console.Clear();
                Console.WriteLine(font);
                Console.WriteLine($"Name: {a.Name}\nSurname: {a.Surname}\nCity: {a.City}");
                Console.Write("Phone (55 555 55 55): ");
                a.Phone = Console.ReadLine()!;
                break;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                _ = Console.ReadKey(true);
            }

        while (true)
            try
            {
                Console.Clear();
                Console.WriteLine(font);
                Console.WriteLine($"Name: {a.Name}\nSurname: {a.Surname}\nCity: {a.City}\nPhone: {a.Phone}");
                Console.Write("Age: ");
                a.Age = Convert.ToInt32(Console.ReadLine());
                break;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                _ = Console.ReadKey(true);
            }

        while (true)
            try
            {
                Console.Clear();
                Console.WriteLine(font);
                Console.WriteLine($"Name: {a.Name}\nSurname: {a.Surname}\nCity: {a.City}\nPhone: {a.Phone}\nAge: {a.Age}");
                Console.Write("Username: ");
                a.Username = Console.ReadLine()!;
                if (Exists(a.Username))
                    throw new("This Username has already been used change Username");
                break;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                _ = Console.ReadKey(true);
            }

        while (true)
            try
            {
                Console.Clear();
                Console.WriteLine(font);
                Console.WriteLine($"Name: {a.Name}\nSurname: {a.Surname}\nCity: {a.City}\nPhone: {a.Phone}\nAge: {a.Age}\nUsername: {a.Username}");
                Console.Write("Password: ");
                a.Password = Console.ReadLine()!;
                break;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                _ = Console.ReadKey(true);
            }

        while (true)
            try
            {
                Console.Clear();
                Console.WriteLine(font);
                Console.WriteLine($"Name: {a.Name}\nSurname: {a.Surname}\nCity: {a.City}\nPhone: {a.Phone}\nAge: {a.Age}\nUsername: {a.Username}\nPassword: {a.Password}");
                Console.Write("Mail: ");
                a.Mail = Console.ReadLine()!;
                break;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                _ = Console.ReadKey(true);
            }
        Random rand = new Random();
        OTPCode = rand.Next(1000, 10000);

        SendMail<string>(a.Mail, OTPCode.ToString());
        //int k = 0;
        //while (k < 3)
        //{
        //    Console.Write(k == 0 ? "Enter your OTP Code that send to your mail: " : $"Try again, {3 - k} chance left: ");
        //    int code = Convert.ToInt32(Console.ReadLine());
        //    if (OTPCode == code)
        //    {
        if (asWorker)
        {
            Worker? w = a as Worker;
            while (true)
                try
                {
                    Console.Clear();
                    Console.WriteLine(font);
                    Console.WriteLine($"Name: {a.Name}\nSurname: {a.Surname}\nCity: {a.City}\nPhone: {a.Phone}\nAge: {a.Age}\nUsername: {a.Username}\nPassword: {a.Password}\nMail: {a.Mail}");
                    Console.Write("Speciality: ");
                    w.Speciality = Console.ReadLine()!;
                    break;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    _ = Console.ReadKey(true);
                }

            if (w is not null)
            {
                workers.Add(w);
                AddLog("New Worker sign up -> ");
            }
        }
        else
        {
            Employer? e = a as Employer;
            while (true)
                try
                {
                    Console.Clear();
                    Console.WriteLine(font);
                    Console.WriteLine($"Name: {a.Name}\nSurname: {a.Surname}\nCity: {a.City}\nPhone: {a.Phone}\nAge: {a.Age}\nUsername: {a.Username}\nPassword: {a.Password}\nMail: {a.Mail}");
                    Console.Write("Company Name: ");
                    e!.Company = Console.ReadLine()!;
                    break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    _ = Console.ReadKey(true);
                }
            if (e is not null)
            {
                employers.Add(e);
                AddLog("New Employer sign up -> ");
            }
        }
        //    break;
        //}
        //Console.WriteLine("Otp code is not correct");
        //k++;
        //if (k == 3)
        //{
        //    Console.WriteLine("Your session has expired You are blocked!!");
        //    AddLog($"{a.Username}'s session expired -> ");
        //    return;
        //}
        //}
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("Login Complated Successfully");
        Console.ForegroundColor = ConsoleColor.White;
        _ = Console.ReadKey(true);
    }
    public static void SignIn()
    {
        Console.Clear();
        Console.WriteLine(font);
        Console.Write("\t\t\t\tEnter Username: ");
        Console.ForegroundColor = ConsoleColor.Green;
        string username = Console.ReadLine()!;
        Console.ResetColor();
        Console.Write("\t\t\t\tEnter Password: ");
        Console.ForegroundColor = ConsoleColor.Green;
        string password = Console.ReadLine()!;
        Console.ResetColor();
        if (username == "Admin")

            if (password == "Admin123")
            {
                AddLog("Admin signed in -> ");
                admin.AdminMenu();
            }
            else
            {
                Console.WriteLine("Incorrect password");
                AddLog("Invalid password entered -> ");
            }

        else if (Exists(username))
        {
            bool found = false;
            foreach (var a in employers)
                if (a.Username == username && a.Password == password)
                {
                    found = true;
                    AddLog($"{a.Username} signed in -> ");
                    a.EmployerMenu();
                }
            if (!found)
                foreach (var a in workers)
                    if (a.Username == username && a.Password == password)
                    {
                        AddLog($"{a.Username} signed in -> ");
                        found = true;
                        a.WorkerMenu();
                    }
            if (!found)
            {
                Console.WriteLine("Incorrect Password");
                AddLog("Invalid password entered -> ");
                _ = Console.ReadKey(true);
            }
        }
        else
        {

            AddLog("Invalid Username entered -> ");
            Console.WriteLine("Invalid Username");
            _ = Console.ReadKey(true);
        }
    }
    public static void SendMail<T>(string _destinationMail, T content, bool HtmlBody = false)
    {
        try
        {
            MailMessage mail = new MailMessage();
            SmtpClient smtp = new SmtpClient("smtp.gmail.com");
            mail.From = new MailAddress("qasimov.vaqif512@gmail.com");
            mail.To.Add(_destinationMail);
            mail.Subject = "**** Boss.az ****";
            mail.Body = content?.ToString() ?? "No content provided.";
            if (HtmlBody)
                mail.IsBodyHtml = true;
            smtp.Port = 587;
            smtp.Credentials = new NetworkCredential("qasimov.vaqif512@gmail.com", "mnnc lpwi nzua ocjg");
            smtp.EnableSsl = true;
            smtp.Send(mail);
            AddLog($"Mail sent to {_destinationMail} -> ");
        }

        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
    }
    public static int PrintList<T>(List<T> list, string listType, bool color = true)
    {
        int i = 0;
        while (true)
        {
            Console.Clear();
            Console.WriteLine(font);
            if (list.Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"{listType} can not be found");
                Console.ForegroundColor = ConsoleColor.White;
                _ = Console.ReadKey(true);
                return -1;
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\t\t\t\t\t\t↑");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(list[i]);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\t\t\t\t\t\t↓");
            Console.ForegroundColor = ConsoleColor.White;

            int a = Control(list.Count, ref i);

            if (a == 1)
                return i;

            else if (a == -1)
                return -1;
        }
    }
    public static int Control(int length, ref int select)
    {
        ConsoleKeyInfo key = Console.ReadKey(true);
        if (key.Key == ConsoleKey.DownArrow)
            select = select != length - 1 ? select + 1 : 0;
        else if (key.Key == ConsoleKey.UpArrow)
            select = select != 0 ? select - 1 : length - 1;
        else if (key.Key == ConsoleKey.Escape)
            return -1;
        else if (key.Key == ConsoleKey.Enter)
            return 1;
        return 0;
    }
    //public static void SerializeToJson(Main main, string filePath)
    //{
    //    // Serialize the Main object to JSON and write it to the file
    //    string json = JsonConvert.SerializeObject(main);
    //    File.WriteAllText("System.json", json);
    //}
    //public static Main DeserializeFromJson(string filePath)
    //{
    //    string json = File.ReadAllText("System.json");

    //    Main main = JsonConvert.DeserializeObject<Main>(json);
    //    return main;
    //}
}