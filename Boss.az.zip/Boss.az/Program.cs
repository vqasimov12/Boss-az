﻿//using Boss.az;
//using Newtonsoft.Json;

//Console.Title = "  BOSS AZ";
////Main main = Boss.az.Main.DeserializeFromJson("System.json");
////Main main = DeserializeFromJson("System.json");
//Main main=new();
//try
//{
//    string json = File.ReadAllText("System.json");

//    // Deserialize JSON data into an instance of the Main class

//    // Deserialize JSON data into an instance of the Main class
//    main = JsonConvert.DeserializeObject<Main>(json);
//}
//catch (Exception e)
//{
//    Console.WriteLine(e.Message);
//    _ = Console.ReadKey(true);
//}
//main?.Start();
//Main.AddLog("Program closed-> ");
//static Main DeserializeFromJson(string filePath)
//{
//    try
//    {
//        // Read JSON from the file
//        string json = File.ReadAllText(filePath);

//        // Deserialize JSON directly into a YourClass instance
//        return JsonConvert.DeserializeObject<Main>(json);
//    }
//    catch (Exception ex)
//    {
//        Console.WriteLine($"Error occurred while deserializing from file: {ex.Message}");
//        return null;
//    }
//}
////SerializeToJson();
////void SerializeToJson()
////{
////    string json = JsonConvert.SerializeObject(main, Formatting.Indented);
////    File.WriteAllText("System.json", json);
////}
///

using Boss.az;

//Main main = new();

//main = Main.DeserializeFromJson("System.json");

//main.Start();
//Main.SerializeToJson(main, "System.json");
AllData.DeserializeConfig();
AllData.main.Start();
AllData.SerializeConfig();